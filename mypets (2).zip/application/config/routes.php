<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['mypets_client'] = 'mypets_client/index';
$route['mypets_client/(:any)'] = 'mypets_client/$1';
