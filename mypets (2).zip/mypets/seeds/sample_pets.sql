INSERT INTO tblmypets (pet_name, pet_type, breed, age, sex, customer_id, created_at) VALUES
('Buddy', 'Dog', 'Labrador Retriever', 3, 'Male', 1, NOW()),
('Luna', 'Cat', 'Persian', 2, 'Female', 1, NOW()),
('Max', 'Dog', 'German Shepherd', 5, 'Male', 2, NOW()),
('Bella', 'Cat', 'Maine Coon', 4, 'Female', 2, NOW()),
('Charlie', 'Dog', 'Golden Retriever', 1, 'Male', 3, NOW()),
('Mia', 'Cat', 'Siamese', 6, 'Female', 3, NOW()),
('Rocky', 'Dog', 'Bulldog', 4, 'Male', 4, NOW()),
('Chloe', 'Cat', 'British Shorthair', 3, 'Female', 4, NOW());
